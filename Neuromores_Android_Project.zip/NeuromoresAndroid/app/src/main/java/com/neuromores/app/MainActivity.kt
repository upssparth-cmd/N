package com.neuromores.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10152B)
private val Panel = Color(0xFF1B2340)
private val Violet = Color(0xFF9B8AFB)
private val Muted = Color(0xFFB9C0D6)
private val Mint = Color(0xFF8FE0C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeuromoresApp() }
    }
}

@Composable
fun NeuromoresApp() {
    var page by remember { mutableStateOf("Home") }
    var mood by remember { mutableStateOf("") }
    var journal by remember { mutableStateOf("") }
    var journalSaved by remember { mutableStateOf(false) }
    var chat by remember { mutableStateOf("") }
    var chatReply by remember { mutableStateOf("Hi! I'm your Neuromores companion. What's on your mind today?") }
    var breathing by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Mood", "Journal", "Buddy", "Breathe").forEach { item ->
                    NavigationBarItem(
                        selected = page == item, onClick = { page = item },
                        icon = {
                            Icon(when(item) {
                                "Home" -> Icons.Default.Home
                                "Mood" -> Icons.Default.Favorite
                                "Journal" -> Icons.Default.EditNote
                                "Buddy" -> Icons.Default.Psychology
                                else -> Icons.Default.Air
                            }, contentDescription = item)
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Violet, selectedTextColor = Violet,
                            indicatorColor = Color(0xFF34305C),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, null, tint = Violet, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("neuromores", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("YOUR MIND. YOUR JOURNEY.", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                    }
                }
                when (page) {
                    "Home" -> {
                        item {
                            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(22.dp)) {
                                Text("YOUR PERSONAL WELLNESS SPACE", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Text("A better mind begins with understanding.", fontSize = 29.sp, fontWeight = FontWeight.Bold, lineHeight = 35.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("Explore your emotions, build healthier habits and take small steps towards a healthier mind.", color = Muted)
                                Spacer(Modifier.height(18.dp))
                                Text("Today’s intention", color = Mint, fontWeight = FontWeight.SemiBold)
                                Text("Take it one moment at a time.", fontSize = 18.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        item {
                            Text("Your wellness space", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            listOf("Mood check-in" to "Track how you feel", "Journal" to "Make space for your thoughts", "Wellness companion" to "A supportive reflection demo", "Breathing" to "Pause and reset").forEach { (title, sub) ->
                                CardRow(title, sub) { page = when(title) {
                                    "Mood check-in" -> "Mood"
                                    "Journal" -> "Journal"
                                    "Wellness companion" -> "Buddy"
                                    else -> "Breathe"
                                } }
                            }
                        }
                    }
                    "Mood" -> {
                        item { Header("Mood tracker", "Checking in with yourself is a powerful first step.") }
                        item {
                            listOf("😊 Happy", "😌 Calm", "🙂 Good", "😐 Neutral", "😟 Anxious", "😔 Sad", "😤 Stressed", "😴 Tired").forEach { option ->
                                CardRow(option, if (mood == option) "Selected" else "Tap to check in") { mood = option }
                            }
                            if (mood.isNotBlank()) Text("Today's mood: $mood", color = Mint, fontWeight = FontWeight.Bold)
                        }
                    }
                    "Journal" -> {
                        item { Header("Your safe space.", "Write freely. There is no right or wrong way to express yourself.") }
                        item {
                            Text("What has been on your mind lately?", color = Muted)
                            OutlinedTextField(value = journal, onValueChange = { journal = it; journalSaved = false },
                                modifier = Modifier.fillMaxWidth().height(190.dp), placeholder = { Text("Start writing here…") })
                            Button(onClick = { journalSaved = journal.isNotBlank() }, enabled = journal.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Save entry") }
                            if (journalSaved) Text("Entry saved for this demo session.", color = Mint)
                        }
                    }
                    "Buddy" -> {
                        item { Header("Neuromores Buddy", "A supportive reflection companion demo — not a therapist or live AI.") }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Text(chatReply, Modifier.padding(18.dp), color = Color.White)
                            }
                            OutlinedTextField(value = chat, onValueChange = { chat = it }, modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Tell me what's on your mind…") })
                            Button(onClick = {
                                if (chat.isNotBlank()) {
                                    chatReply = "Thank you for sharing. It sounds like this matters to you. Take a moment to acknowledge how you feel. Would you like to explore what's behind that feeling?"
                                    chat = ""
                                }
                            }, enabled = chat.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Send") }
                        }
                    }
                    else -> {
                        item { Header("Breathe & reset", "A short pause can help you reconnect with the present.") }
                        item {
                            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Air, null, tint = Mint, modifier = Modifier.size(54.dp))
                                Spacer(Modifier.height(12.dp))
                                Text(if (breathing) "Breathe in… and gently out." else "Ready for a mindful pause?", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(14.dp))
                                Button(onClick = { breathing = !breathing }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                                    Text(if (breathing) "Finish exercise" else "Start breathing")
                                }
                            }
                        }
                    }
                }
                item {
                    Text("Neuromores is a wellness and self-reflection tool, not a medical service. If you are in immediate danger or crisis, contact local emergency services or a qualified professional.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted)
    }
}

@Composable
fun CardRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Violet)
        }
    }
}
