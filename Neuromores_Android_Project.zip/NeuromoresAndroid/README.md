# Neuromores Android prototype

A premium, dark-themed Android wellness prototype built with Kotlin and Jetpack Compose.

## Features
- Home dashboard
- Mood check-in (session-only)
- Journal entry demo
- Scripted wellness companion demo
- Breathing exercise start/stop interaction

## Build an APK
1. Install Android Studio (current stable) with Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle installed, so this project is supplied as source and has not been compiled or tested as an APK.

## Important
This is a prototype, not a clinical mental-health product. The companion is scripted, and entries are not persisted to a secure account or cloud database. Do not use it for diagnosis, treatment, or emergency support.
