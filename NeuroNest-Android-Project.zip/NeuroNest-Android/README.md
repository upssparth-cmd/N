# Neuro Nest Android APK

This project packages the supplied single-file Neuro Nest HTML prototype in a lightweight Android WebView app.

## Build the APK automatically (recommended on phone/tablet)

1. Create or open a GitHub repository.
2. Upload **all files and folders** from this project ZIP into the repository root (keep `.github/workflows/build-apk.yml`).
3. Commit the files to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Select **Build Neuro Nest APK** and open the latest successful run.
6. Under **Artifacts**, download `neuro-nest-debug-apk`. Extract the ZIP to get `app-debug.apk`.
7. Open the APK on Android and allow installation from that source if Android asks.

A push to `main`/`master` also triggers a build automatically.

## Build locally

Requires JDK 17, Android SDK 35, and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Notes

- The supplied UI and JavaScript are bundled locally; no website hosting is required.
- The prototype stores its app data in browser local storage on the device.
- The exposed API key from the supplied HTML was removed. Cloud AI is therefore unavailable in this APK; the prototype's built-in offline companion remains.
- This is a debug APK for testing, not a Play Store-signed release.
- Review privacy, mental-health safety, and accessibility behavior before public distribution.
